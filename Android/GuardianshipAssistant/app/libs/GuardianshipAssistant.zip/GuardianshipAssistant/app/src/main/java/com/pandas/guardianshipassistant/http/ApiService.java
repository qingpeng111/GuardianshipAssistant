package com.pandas.guardianshipassistant.http;

public interface ApiService {

}
