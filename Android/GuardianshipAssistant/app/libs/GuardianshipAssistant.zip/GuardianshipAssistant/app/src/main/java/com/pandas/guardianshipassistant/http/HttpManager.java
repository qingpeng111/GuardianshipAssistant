package com.pandas.guardianshipassistant.http;

public class HttpManager  {


}
