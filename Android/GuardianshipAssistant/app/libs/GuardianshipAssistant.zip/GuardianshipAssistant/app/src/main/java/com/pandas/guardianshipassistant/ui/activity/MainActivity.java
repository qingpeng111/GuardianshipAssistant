package com.pandas.guardianshipassistant.ui.activity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.pandas.guardianshipassistant.R;
import com.pandas.guardianshipassistant.ui.adapter.ViewPagerAdapter;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayout;
    @BindView(R.id.left_navigation_view)
    NavigationView leftNavigationView;
    @BindView(R.id.tool_bar)
    Toolbar toolBar;
    @BindView(R.id.view_pager)
    ViewPager viewPager;
    @BindView(R.id.tab_layout)
    TabLayout tabLayout;

    private View headerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initDrawerLayout();

        initTablayout();

    }

    //初始化
    private void initTablayout() {
        PagerAdapter adapter=new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }


    //主要界面
    private void initDrawerLayout() {

//        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
//            @Override
//            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {
//                Log.d("MainActivity", "onDrawerSlide");
//            }
//
//            @Override
//            public void onDrawerOpened(@NonNull View drawerView) {
//                Log.d("MainActivity", "onDrawerOpened");
//            }
//
//            @Override
//            public void onDrawerClosed(@NonNull View drawerView) {
//                Log.d("MainActivity", "onDrawerClosed");
//            }
//
//            @Override
//            public void onDrawerStateChanged(int newState) {
//                Log.d("MainActivity", "onDrawerStateChanged");
//            }
//        });

        //点击头像
        headerView = leftNavigationView.getHeaderView(0);
        headerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "头像点击了", Toast.LENGTH_LONG).show();
            }
        });

        leftNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.left_menu_home:
                        Toast.makeText(MainActivity.this, "主页", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.left_menu_update:
                        Toast.makeText(MainActivity.this, "更新", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.left_menu_download:
                        Toast.makeText(MainActivity.this, "下载", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.left_menu_tools:
                        Toast.makeText(MainActivity.this, "工具", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.left_menu_share:
                        Toast.makeText(MainActivity.this, "分享", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.left_menu_send:
                        Toast.makeText(MainActivity.this, "发送", Toast.LENGTH_LONG).show();
                        break;
                }
                return false;
            }
        });


        //整合tooBar和drawerLayout
        toolBar.inflateMenu(R.menu.toolbar_menu);//右边的三个点

        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolBar, R.string.open, R.string.closed);
        drawerToggle.syncState();
        System.out.println("开始-----------------------------");
        drawerLayout.addDrawerListener(drawerToggle);
        System.out.println("结束-------------------");
    }
}
