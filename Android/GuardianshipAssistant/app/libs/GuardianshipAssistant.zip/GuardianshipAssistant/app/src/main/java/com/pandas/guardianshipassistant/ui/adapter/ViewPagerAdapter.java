package com.pandas.guardianshipassistant.ui.adapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.pandas.guardianshipassistant.ui.bean.FragmengtInfo;
import com.pandas.guardianshipassistant.ui.fragment.ChatFragment;
import com.pandas.guardianshipassistant.ui.fragment.ContactFragment;
import com.pandas.guardianshipassistant.ui.fragment.FindFragment;
import com.pandas.guardianshipassistant.ui.fragment.GuardFragment;
import com.pandas.guardianshipassistant.ui.fragment.MyFragment;

import java.util.ArrayList;
import java.util.List;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {
    private List<FragmengtInfo>mFragments=new ArrayList<>(5);
    public ViewPagerAdapter( FragmentManager fm) {
        super(fm);
        initFragment();
    }

    public void initFragment(){

        mFragments.add(new FragmengtInfo("聊天", ChatFragment.class));
        mFragments.add(new FragmengtInfo("通讯录", ContactFragment.class));
        mFragments.add(new FragmengtInfo("监护", GuardFragment.class));
        mFragments.add(new FragmengtInfo("发现", FindFragment.class));
        mFragments.add(new FragmengtInfo("我的", MyFragment.class));


    }


    @NonNull
    @Override
    public Fragment getItem(int position) {

        try{
            return (Fragment) mFragments.get(position).getFragment().newInstance();
        }catch (InstantiationException e){
            e.printStackTrace();
        }catch(IllegalAccessException e){
            e.printStackTrace();
        }
        return null;
//        Fragment fragment=null;
//        switch (position){
//
//            case 0:
//
//                break;
//            case 0:
//
//                break;
//
//            case 0:
//
//                break;
//
//            case 0:
//
//                break;
//
//            case 0:
//
//                break;
//
//
//
//
//        }
//        return mFragments.get(0);
    }

    @Override
    public int getCount() {
        return mFragments.size();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mFragments.get(position).getTitle();
    }
}
