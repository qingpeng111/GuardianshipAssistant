package com.pandas.guardianshipassistant.ui.bean;

import androidx.fragment.app.Fragment;

public class FragmengtInfo {
    private  String title;
    private Class fragment;


    public FragmengtInfo(String title, Class fragment) {
        this.title = title;
        this.fragment = fragment;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setFragment(Class fragment) {
        this.fragment = fragment;
    }

    public String getTitle() {
        return title;
    }

    public Class getFragment() {
        return fragment;
    }
}
